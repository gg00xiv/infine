﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Microsoft.ApplicationServer.Caching;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            TestSearch();

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        static void TestSearch()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetCache("InfineGroup");
            
            cache.CreateRegion("Desk");
            var rnd=new Random();
            for (var i = 0; i < 1000; i++) {
                var tagParite = new DataCacheTag(i % 2 == 0 ? "Paire" : "Impaire");
                var tagRandom = new DataCacheTag(rnd.Next(100).ToString());
                cache.Put("int-" + i, i, new[] { tagParite, tagRandom }, "Desk");
            }

            foreach (var pair in cache.GetObjectsByTag(new DataCacheTag("67"), "Desk"))
            {
                var item = cache.GetCacheItem(pair.Key, "Desk");
                Console.WriteLine("{0} : {1} [Tag: {2}]", pair.Key, pair.Value, string.Join(",", item.Tags));
            }
        }

        static void TestLock()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetCache("InfineGroup");

            cache.Put("int", 5);

            DataCacheLockHandle lockHandle;
            var value = cache.GetAndLock("int", TimeSpan.FromSeconds(5), out lockHandle);
            Console.WriteLine("GetAndLock: int = {0}", value);

            try
            {
                value = cache.GetAndLock("int", TimeSpan.FromSeconds(5), out lockHandle);
                Console.WriteLine("GetAndLock: int = {0}", value);
            }
            catch (DataCacheException ex)
            {
                if (ex.ErrorCode == DataCacheErrorCode.ObjectLocked)
                    Console.WriteLine("GetAndLock failed, object already locked.");
                else
                    throw ex;
            }

            var timer = new Timer(new TimerCallback(o =>
            {
                Console.WriteLine("GetAndLock(after 6s): int = {0}", cache.GetAndLock("int", TimeSpan.FromSeconds(5), out lockHandle));
            }), null, 6000, Timeout.Infinite);
        }

        static void TestCacheItem()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetCache("InfineGroup");

            cache.Put("int", 5, TimeSpan.FromSeconds(15));

            var item = cache.GetCacheItem("int");

            Console.WriteLine("CacheItem informations :");
            foreach (var prop in item.GetType().GetProperties())
            {
                Console.WriteLine("{0} = {1}", prop.Name, prop.GetValue(item, null));
            }
        }

        static void TestBulkGet()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetCache("InfineGroup");

            cache.CreateRegion("Desk");

            var rnd = new Random();
            for (var i = 0; i < 1000; i++)
            {
                cache.Put("int-" + i, rnd.Next(), "Desk");
            }

            var gets = cache.BulkGet(new[] { "int-6", "int-14", "int-578", "int-988" }, "Desk");
            foreach (var value in gets)
            {
                Console.WriteLine("{0} = {1}", value.Key, value.Value);
            }
        }

        static void TestNotifications()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetCache("InfineGroup");

            cache.AddFailureNotificationCallback(new DataCacheFailureNotificationCallback(CacheFailed));

            var rnd = new Random();
            cache.Put("int", rnd.Next());

            var allCacheOperations = DataCacheOperations.AddItem | DataCacheOperations.ReplaceItem |
                DataCacheOperations.RemoveItem | DataCacheOperations.CreateRegion |
                DataCacheOperations.ClearRegion | DataCacheOperations.RemoveRegion;

            cache.AddCacheLevelCallback(allCacheOperations,
                new DataCacheNotificationCallback(CacheUpdated));

            cache.Remove("int");
            cache.Put("int", rnd.Next());
            cache.Put("int", rnd.Next());
        }

        static void CacheFailed(string errorMessage, DataCacheNotificationDescriptor descriptor)
        {
            Console.WriteLine("ERROR : {0}", errorMessage);
        }

        static void CacheUpdated(string cacheName, string region, string key,
            DataCacheItemVersion version, DataCacheOperations operation,
            DataCacheNotificationDescriptor descriptor)
        {
            //display some of the delegate parameters
            Console.WriteLine("A cache-level notification was triggered!");
            Console.WriteLine("    Cache: " + cacheName);
            Console.WriteLine("    Region: " + region);
            Console.WriteLine("    Key: " + key);
            Console.WriteLine("    Operation: " + operation);
            Console.WriteLine("======================================================");
        }

        static void TestDefaultCache()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetDefaultCache();

            cache.Put("int", 5);
            Console.WriteLine("int : {0}", cache.Get("int"));
        }

        static void ListRegions()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetCache("InfineGroup");

            foreach (var r in cache.GetSystemRegions())
                Console.WriteLine("Region : {0}", r);
        }

        static void TestRegion()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetCache("InfineGroup");

            cache.Put("int", 5);
            cache.Put("int", 6, "RegionA");
            cache.Put("int", 7, "RegionB");


            Console.WriteLine("int(no region) : {0}", cache.Get("int"));
            Console.WriteLine("int(RegionA) : {0}", cache.Get("int", "RegionA"));
            Console.WriteLine("int(RegionB) : {0}", cache.Get("int", "RegionB"));
        }

        static void TestBasicExpiration()
        {
            var factory = new DataCacheFactory();
            var cache = factory.GetDefaultCache();

            cache.Put("obj", new object(), TimeSpan.FromSeconds(5));

            var timer = new Timer(new TimerCallback(o =>
            {
                Console.WriteLine("obj : {0}", cache.Get("obj"));
            }), null, 0, 1000);
        }
    }
}
